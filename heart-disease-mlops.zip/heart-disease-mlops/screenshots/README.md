# Screenshots folder

Put the evidence screenshots referenced in `reports/report_template.md`
here, e.g.:

- `01_eda_notebook.png`
- `02_mlflow_runs.png`
- `03_pytest_passing.png`
- `04_github_actions_green.png`
- `05_github_actions_failed_example.png`
- `06_docker_build.png`
- `07_docker_run_predict.png`
- `08_k8s_pods_svc.png` or `08_vm_docker_ps.png`
- `09_deployed_endpoint_curl.png`
- `10_grafana_dashboard.png`
- `11_api_logs.png`
