<!--
  Report skeleton for MLOps Assignment 01 (AIMLCZG523).
  Fill in every [TODO] with your own screenshots, numbers and commentary
  before converting to PDF/DOCX for submission. Aim for ~10 pages.
  Export tip: open this in VS Code / Typora / Pandoc and export to PDF, e.g.
      pandoc reports/report_template.md -o reports/MLOps_Assignment01_Report.pdf
-->

# MLOps Experimental Learning Assignment 01
## Heart Disease Risk Prediction - End-to-End ML Pipeline

**Name:** [TODO: your name]
**BITS ID:** [TODO]
**Course:** AIMLCZG523 - Machine Learning Operations
**Date:** [TODO]
**Repository:** [TODO: GitHub URL]
**Deployed API URL / access instructions:** [TODO]
**Video walkthrough:** [TODO: link]

---

## 1. Problem Statement & Objective

[TODO: 1 short paragraph in your own words - what the model predicts, why
it matters, and what "production-ready" means for this assignment
(reproducible, tested, containerized, monitored, deployed).]

## 2. Architecture Overview

[TODO: paste/describe the architecture diagram from the README, or draw
your own. Briefly walk through each stage: data -> preprocessing -> training
+ tracking -> packaging -> API -> container -> deployment -> monitoring.]

**Figure 1.** Architecture diagram.
`[TODO: screenshot/diagram here]`

## 3. Dataset & Setup Instructions

- Source: UCI Machine Learning Repository, Heart Disease dataset (id=45)
- Rows / columns: [TODO: fill from your own `data/raw/heart_disease_uci.csv`]
- Download: `python data/download_data.py`

### 3.1 Setup instructions (copy from README, adapt if you changed anything)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python data/download_data.py
python src/eda.py
python src/train.py
pytest
```

## 4. Exploratory Data Analysis

[TODO: summarize your own observations - don't just restate the numbers,
explain what they mean clinically/statistically.]

- Missing values found: [TODO]
- Class balance: [TODO - no-disease vs disease counts/percentages]
- Most correlated features with target: [TODO]
- Any outliers / data quality issues you noticed and how you handled them: [TODO]

**Figure 2.** Feature distributions.
`[TODO: reports/figures/01_histograms.png]`

**Figure 3.** Correlation heatmap.
`[TODO: reports/figures/02_correlation_heatmap.png]`

**Figure 4.** Class balance.
`[TODO: reports/figures/03_class_balance.png]`

## 5. Feature Engineering & Modelling Choices

- Numeric features (median-impute + scale): `age, trestbps, chol, thalach, oldpeak`
- Binary features (most-frequent impute): `sex, fbs, exang`
- Categorical features (most-frequent impute + one-hot): `cp, restecg, slope, ca, thal`

[TODO: explain *why* you grouped features this way, and whether you changed
anything from the default in this repo - e.g. did you try target encoding,
binning age, dropping a weakly-correlated feature, etc.?]

### 5.1 Models trained

| Model | Hyperparameter grid | Best params (your run) | CV ROC-AUC |
|---|---|---|---|
| Logistic Regression | C: [0.01,0.1,1,5,10] | [TODO] | [TODO] |
| Random Forest | n_estimators/max_depth/min_samples_leaf grid | [TODO] | [TODO] |

### 5.2 Test-set evaluation

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| Logistic Regression | | | | | |
| Random Forest | | | | | |

*(fill from `reports/model_comparison.csv` after running `python src/train.py`)*

**Figure 5/6.** Confusion matrices & ROC curves.
`[TODO: reports/figures/confusion_matrix_*.png, roc_curve_*.png]`

[TODO: which model did you pick as "best" and why - not just the highest
ROC-AUC, but any tradeoffs (interpretability, recall for the disease class
given the clinical cost of false negatives, etc.)]

## 6. Experiment Tracking (MLflow)

[TODO: screenshot the MLflow UI (`mlflow ui --backend-store-uri
sqlite:///mlflow.db`) showing your runs, and summarize: how many runs, what
was logged (params/metrics/artifacts), how you used it to pick the final
model.]

**Figure 7.** MLflow experiment runs.
`[TODO: screenshot]`

## 7. Model Packaging & Reproducibility

- Final model format: `models/model.pkl` (scikit-learn `Pipeline` -
  preprocessing + classifier bundled together, so inference never needs the
  raw features re-transformed by hand)
- `models/metadata.json` records the winning model name, hyperparameters,
  MLflow run id and test metrics
- `requirements.txt` pins exact versions for a clean-room `pip install`
- Reproduce end-to-end: `python data/download_data.py && python
  src/eda.py && python src/train.py`

[TODO: note any environment-specific gotchas you hit and how you resolved them.]

## 8. CI/CD Pipeline & Automated Testing

- Unit tests: `tests/test_data_preprocessing.py` (cleaning, imputation,
  unseen-category handling), `tests/test_api.py` (health, predict, validation
  errors, metrics) - [TODO: X] tests, all passing
- Pipeline (`.github/workflows/ci-cd.yml`): lint -> train+test -> docker build & smoke test

**Figure 8.** Green GitHub Actions run.
`[TODO: screenshot]`

**Figure 9.** A deliberately broken run (e.g. a failing test or lint error),
showing the pipeline correctly fails with a clear error.
`[TODO: screenshot]`

## 9. Model Containerization

```bash
docker build -t heart-disease-api:latest -f deployment/Dockerfile .
docker run --rm -p 8000:8000 heart-disease-api:latest
curl -X POST http://localhost:8000/predict -H "Content-Type: application/json" -d '{...}'
```

**Figure 10.** `docker build` succeeding.
`[TODO: screenshot]`

**Figure 11.** Container running + a sample `/predict` call and response.
`[TODO: screenshot]`

## 10. Production Deployment

[TODO: pick ONE and document it with screenshots - Kubernetes (Minikube/
cloud) or a cloud VM, per README section 6/7.]

- Target: [TODO: Minikube / GKE / EKS / AKS / AWS EC2 / Azure VM / GCP Compute Engine]
- Exposed via: [TODO: LoadBalancer / Ingress / direct VM port]
- Public/accessible URL: [TODO]

**Figure 12.** Deployment manifest applied / container running on the VM.
`[TODO: screenshot - e.g. `kubectl get pods`/`kubectl get svc`, or `docker ps` on the VM]`

**Figure 13.** Successful request against the deployed endpoint.
`[TODO: screenshot]`

## 11. Monitoring & Logging

[TODO: screenshot the Grafana dashboard after generating some traffic, and
describe what each panel shows and why you chose those metrics.]

**Figure 14.** API request logs.
`[TODO: screenshot of `docker logs heart-disease-api` or similar]`

**Figure 15.** Grafana dashboard.
`[TODO: screenshot]`

## 12. Challenges & Learnings

[TODO: 1-2 paragraphs, genuinely your own - what was hardest, what you'd do
differently with more time (e.g. SHAP explainability, a model registry,
canary deployments, autoscaling, alerting rules).]

## 13. Conclusion

[TODO: 3-5 sentences summarizing what was built and the final model's
performance.]

---

## Appendix: Repository Structure

[TODO: paste the repo layout from the README, or `tree -L 2` output.]
