"""Unit tests for src/data_preprocessing.py"""
import numpy as np
import pandas as pd
import pytest

from data_preprocessing import (
    BINARY_FEATURES,
    CATEGORICAL_FEATURES,
    NUMERIC_FEATURES,
    RAW_COLUMNS,
    TARGET_COLUMN,
    build_preprocessing_pipeline,
    clean_data,
    load_raw_data,
    split_features_target,
)


@pytest.fixture
def raw_df():
    """A tiny synthetic raw dataframe mimicking the UCI schema, including
    a missing value encoded as '?' and one exact duplicate row, and a
    multi-class target (as in the original UCI data) to test binarisation."""
    rows = [
        [63, 1, 3, 145, 233, 1, 0, 150, 0, 2.3, 0, "0", "1", 0],
        [37, 1, 2, 130, 250, 0, 1, 187, 0, 3.5, 0, "0", "2", 2],   # multi-class target
        [41, 0, 1, 130, 204, 0, 0, 172, 0, 1.4, 2, "?", "2", 1],  # '?' missing value
        [41, 0, 1, 130, 204, 0, 0, 172, 0, 1.4, 2, "?", "2", 1],  # exact duplicate of row above
    ]
    return pd.DataFrame(rows, columns=RAW_COLUMNS)


def test_load_raw_data_rejects_missing_columns(tmp_path):
    bad_csv = tmp_path / "bad.csv"
    pd.DataFrame({"age": [1], "sex": [1]}).to_csv(bad_csv, index=False)
    with pytest.raises(ValueError):
        load_raw_data(bad_csv)


def test_load_raw_data_roundtrip(tmp_path, raw_df):
    csv_path = tmp_path / "raw.csv"
    raw_df.to_csv(csv_path, index=False)
    loaded = load_raw_data(csv_path)
    assert list(loaded.columns) == RAW_COLUMNS
    assert len(loaded) == len(raw_df)


def test_clean_data_handles_question_marks(raw_df):
    cleaned = clean_data(raw_df)
    # '?' should have become NaN, not the string "?"
    assert not cleaned.astype(str).eq("?").any().any()


def test_clean_data_drops_exact_duplicates(raw_df):
    cleaned = clean_data(raw_df)
    # the fixture has one exact duplicate row -> should be removed
    assert len(cleaned) == len(raw_df) - 1


def test_clean_data_binarises_target(raw_df):
    cleaned = clean_data(raw_df)
    assert set(cleaned[TARGET_COLUMN].unique()).issubset({0, 1})


def test_split_features_target_shapes(raw_df):
    cleaned = clean_data(raw_df)
    X, y = split_features_target(cleaned)
    assert len(X) == len(y) == len(cleaned)
    assert TARGET_COLUMN not in X.columns
    assert set(X.columns) == set(NUMERIC_FEATURES + BINARY_FEATURES + CATEGORICAL_FEATURES)


def test_preprocessing_pipeline_fits_and_transforms_with_missing_values(raw_df):
    cleaned = clean_data(raw_df)
    X, y = split_features_target(cleaned)
    pipeline = build_preprocessing_pipeline()
    transformed = pipeline.fit_transform(X)
    # output must be fully numeric and contain no NaNs after imputation
    arr = np.asarray(transformed.todense() if hasattr(transformed, "todense") else transformed)
    assert not np.isnan(arr).any()
    assert arr.shape[0] == len(X)


def test_preprocessing_pipeline_handles_unseen_category_at_inference(raw_df):
    """OneHotEncoder(handle_unknown='ignore') must not crash on a category
    value that was never seen during fit (a very realistic production
    scenario: a new patient with an unusual code)."""
    cleaned = clean_data(raw_df)
    X, y = split_features_target(cleaned)
    pipeline = build_preprocessing_pipeline()
    pipeline.fit(X, y)

    unseen = X.iloc[[0]].copy()
    unseen["thal"] = 99  # a thal code never seen during fit
    transformed = pipeline.transform(unseen)  # should not raise
    assert transformed.shape[0] == 1
