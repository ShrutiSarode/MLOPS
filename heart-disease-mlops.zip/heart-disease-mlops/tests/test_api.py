"""
Unit/integration tests for the FastAPI serving app (src/api/main.py).

Uses FastAPI's TestClient, which drives the app in-process (no network
socket needed), so these tests run fast and are safe inside CI. They require
a trained model at models/model.pkl - the GitHub Actions workflow trains the
model as a prior step before running the test suite.
"""
import pytest
from fastapi.testclient import TestClient

from api.main import app

SAMPLE_PATIENT = {
    "age": 63, "sex": 1, "cp": 3, "trestbps": 145, "chol": 233,
    "fbs": 1, "restecg": 0, "thalach": 150, "exang": 0,
    "oldpeak": 2.3, "slope": 0, "ca": 0, "thal": 1,
}


@pytest.fixture
def client():
    with TestClient(app) as c:  # triggers startup event -> loads the model
        yield c


def test_root(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "service" in resp.json()


def test_health_ok_when_model_present(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["model_loaded"] is True


def test_predict_returns_valid_response(client):
    resp = client.post("/predict", json=SAMPLE_PATIENT)
    assert resp.status_code == 200
    body = resp.json()
    assert body["prediction"] in (0, 1)
    assert body["label"] in ("disease", "no_disease")
    assert 0.0 <= body["confidence"] <= 1.0
    assert 0.0 <= body["probability_disease"] <= 1.0


def test_predict_missing_field_returns_422(client):
    incomplete = {k: v for k, v in SAMPLE_PATIENT.items() if k != "age"}
    resp = client.post("/predict", json=incomplete)
    assert resp.status_code == 422


def test_predict_out_of_range_value_returns_422(client):
    bad = dict(SAMPLE_PATIENT, sex=7)  # sex must be 0 or 1
    resp = client.post("/predict", json=bad)
    assert resp.status_code == 422


def test_predict_wrong_type_returns_422(client):
    bad = dict(SAMPLE_PATIENT, age="not-a-number")
    resp = client.post("/predict", json=bad)
    assert resp.status_code == 422


def test_metrics_endpoint_exposes_prometheus_format(client):
    resp = client.get("/metrics")
    assert resp.status_code == 200
    assert "python_gc_objects_collected_total" in resp.text or "# HELP" in resp.text
