"""
Exploratory Data Analysis for the Heart Disease UCI dataset.

Generates and saves:
  - per-feature histograms
  - a correlation heatmap
  - a class-balance bar chart
  - a boxplot of key numeric features split by target
  - a text summary (shape, dtypes, missing values, class balance)

Run:
    python src/eda.py
Output:
    reports/figures/*.png
    reports/eda_summary.txt
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # headless/non-interactive backend, safe for CI & servers
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from data_preprocessing import (
    NUMERIC_FEATURES,
    RAW_COLUMNS,
    TARGET_COLUMN,
    load_and_clean,
    load_raw_data,
)

sns.set_theme(style="whitegrid", palette="muted")

FIG_DIR = Path("reports/figures")
SUMMARY_PATH = Path("reports/eda_summary.txt")


def plot_histograms(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(4, 4, figsize=(18, 14))
    axes = axes.flatten()
    for i, col in enumerate(RAW_COLUMNS):
        sns.histplot(df[col], kde=True, ax=axes[i], color="#4C72B0")
        axes[i].set_title(col)
    for j in range(len(RAW_COLUMNS), len(axes)):
        fig.delaxes(axes[j])
    fig.suptitle("Feature distributions - Heart Disease UCI dataset", fontsize=16)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(FIG_DIR / "01_histograms.png", dpi=150)
    plt.close(fig)


def plot_correlation_heatmap(df: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(11, 9))
    corr = df.corr(numeric_only=True)
    sns.heatmap(
        corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
        square=True, linewidths=0.5, ax=ax,
    )
    ax.set_title("Feature correlation heatmap")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "02_correlation_heatmap.png", dpi=150)
    plt.close(fig)


def plot_class_balance(df: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(6, 5))
    counts = df[TARGET_COLUMN].value_counts().sort_index()
    labels = ["No disease (0)", "Disease (1)"]
    bars = ax.bar(labels, counts.values, color=["#55A868", "#C44E52"])
    for bar, count in zip(bars, counts.values):
        ax.text(bar.get_x() + bar.get_width() / 2, count + 2, str(count),
                ha="center", fontweight="bold")
    ax.set_title("Class balance: presence of heart disease")
    ax.set_ylabel("Number of patients")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "03_class_balance.png", dpi=150)
    plt.close(fig)


def plot_boxplots_by_target(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, len(NUMERIC_FEATURES), figsize=(4 * len(NUMERIC_FEATURES), 5))
    for ax, col in zip(axes, NUMERIC_FEATURES):
        sns.boxplot(
            x=TARGET_COLUMN, y=col, data=df, hue=TARGET_COLUMN, ax=ax,
            palette=["#55A868", "#C44E52"], legend=False,
        )
        ax.set_xlabel("target (0=no disease, 1=disease)")
    fig.suptitle("Key numeric features vs. target", fontsize=14)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(FIG_DIR / "04_boxplots_by_target.png", dpi=150)
    plt.close(fig)


def write_summary(df_raw: pd.DataFrame, df_clean: pd.DataFrame) -> None:
    lines = []
    lines.append("HEART DISEASE UCI DATASET - EDA SUMMARY")
    lines.append("=" * 50)
    lines.append(f"\nRaw shape   : {df_raw.shape}")
    lines.append(f"Clean shape : {df_clean.shape}")
    lines.append("\nMissing values in raw data (post '?' -> NaN coercion):")
    raw_na = df_raw.replace("?", pd.NA).isna().sum()
    lines.append(raw_na[raw_na > 0].to_string() if raw_na.sum() else "  none found")
    lines.append("\nDtypes (clean):")
    lines.append(df_clean.dtypes.to_string())
    lines.append("\nDescribe (clean):")
    lines.append(df_clean.describe().to_string())
    lines.append("\nClass balance (clean):")
    vc = df_clean[TARGET_COLUMN].value_counts()
    vc_pct = df_clean[TARGET_COLUMN].value_counts(normalize=True) * 100
    for cls in vc.index:
        lines.append(f"  class {cls}: {vc[cls]} rows ({vc_pct[cls]:.1f}%)")
    SUMMARY_PATH.write_text("\n".join(lines))
    print(f"Wrote summary -> {SUMMARY_PATH}")


def main(raw_path: str = "data/raw/heart_disease_uci.csv") -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df_raw = load_raw_data(raw_path)
    df_clean = load_and_clean(raw_path)

    plot_histograms(df_clean)
    plot_correlation_heatmap(df_clean)
    plot_class_balance(df_clean)
    plot_boxplots_by_target(df_clean)
    write_summary(df_raw, df_clean)

    # Also persist the cleaned dataset for downstream steps / reproducibility
    processed_path = Path("data/processed/heart_disease_clean.csv")
    processed_path.parent.mkdir(parents=True, exist_ok=True)
    df_clean.to_csv(processed_path, index=False)
    print(f"Wrote cleaned dataset -> {processed_path}")
    print(f"Figures written to -> {FIG_DIR}/")


if __name__ == "__main__":
    main()
