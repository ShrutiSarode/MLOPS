"""
Train, tune, evaluate and track heart-disease classification models.

Trains two classifiers (Logistic Regression, Random Forest) inside a single
sklearn Pipeline (preprocessing + estimator), tunes each with GridSearchCV +
stratified k-fold cross-validation, evaluates on a held-out test set, and
logs every run (params, metrics, plots, the fitted pipeline) to MLflow.

The best run (by test ROC-AUC) is re-saved as the "production" artifact at
models/model.pkl, together with a small models/metadata.json describing it,
so the serving API (src/api/main.py) can load it without any MLflow
dependency at inference time.

Run:
    python src/train.py
    python src/train.py --data data/processed/heart_disease_clean.csv --cv 5

View experiment results:
    mlflow ui --backend-store-uri mlruns   # http://127.0.0.1:5000
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mlflow
import mlflow.sklearn
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline

from data_preprocessing import (
    build_preprocessing_pipeline,
    load_and_clean,
    split_features_target,
)

MODELS_DIR = Path("models")
FIG_DIR = Path("reports/figures")
RANDOM_STATE = 42

MODEL_GRID = {
    "logistic_regression": {
        "estimator": LogisticRegression(max_iter=2000, random_state=RANDOM_STATE),
        "param_grid": {
            "clf__C": [0.01, 0.1, 1.0, 5.0, 10.0],
            "clf__solver": ["lbfgs"],
        },
    },
    "random_forest": {
        "estimator": RandomForestClassifier(random_state=RANDOM_STATE),
        "param_grid": {
            "clf__n_estimators": [100, 200, 400],
            "clf__max_depth": [3, 5, 8, None],
            "clf__min_samples_leaf": [1, 2, 4],
        },
    },
}


def evaluate(estimator, X_test, y_test) -> dict:
    y_pred = estimator.predict(X_test)
    y_proba = estimator.predict_proba(X_test)[:, 1]
    return {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred, zero_division=0),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
    }, y_pred, y_proba


def log_confusion_matrix(y_test, y_pred, model_name: str) -> Path:
    fig, ax = plt.subplots(figsize=(5, 5))
    cm = confusion_matrix(y_test, y_pred)
    ConfusionMatrixDisplay(cm, display_labels=["No disease", "Disease"]).plot(
        ax=ax, cmap="Blues", colorbar=False
    )
    ax.set_title(f"Confusion matrix - {model_name}")
    fig.tight_layout()
    out = FIG_DIR / f"confusion_matrix_{model_name}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return out


def log_roc_curve(estimator, X_test, y_test, model_name: str) -> Path:
    fig, ax = plt.subplots(figsize=(5, 5))
    RocCurveDisplay.from_estimator(estimator, X_test, y_test, ax=ax)
    ax.set_title(f"ROC curve - {model_name}")
    fig.tight_layout()
    out = FIG_DIR / f"roc_curve_{model_name}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return out


def run_model(name: str, spec: dict, X_train, X_test, y_train, y_test, cv_folds: int) -> dict:
    preprocessor = build_preprocessing_pipeline()
    pipe = Pipeline(steps=[("preprocess", preprocessor), ("clf", spec["estimator"])])

    cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_STATE)
    search = GridSearchCV(
        pipe, spec["param_grid"], scoring="roc_auc", cv=cv, n_jobs=-1, refit=True,
    )

    with mlflow.start_run(run_name=name):
        search.fit(X_train, y_train)
        best_pipe = search.best_estimator_

        mlflow.log_param("model_type", name)
        for k, v in search.best_params_.items():
            mlflow.log_param(k.replace("clf__", ""), v)
        mlflow.log_param("cv_folds", cv_folds)

        mlflow.log_metric("cv_best_roc_auc", search.best_score_)

        test_metrics, y_pred, y_proba = evaluate(best_pipe, X_test, y_test)
        for metric_name, value in test_metrics.items():
            mlflow.log_metric(f"test_{metric_name}", value)

        cm_path = log_confusion_matrix(y_test, y_pred, name)
        roc_path = log_roc_curve(best_pipe, X_test, y_test, name)
        mlflow.log_artifact(str(cm_path))
        mlflow.log_artifact(str(roc_path))

        # serialization_format="pickle": avoids mlflow's newer default skops
        # serializer rejecting numpy/sklearn internal dtypes as "untrusted";
        # pickle is fine here since we are both producer and consumer of the
        # artifact within this project's own trusted pipeline.
        mlflow.sklearn.log_model(best_pipe, name="model", serialization_format="pickle")

        run_id = mlflow.active_run().info.run_id

    print(f"[{name}] best params: {search.best_params_}")
    print(f"[{name}] CV best ROC-AUC: {search.best_score_:.4f}")
    print(f"[{name}] test metrics: {test_metrics}")

    return {
        "name": name,
        "run_id": run_id,
        "pipeline": best_pipe,
        "cv_best_roc_auc": search.best_score_,
        "best_params": search.best_params_,
        "test_metrics": test_metrics,
    }


def main(data_path: str, cv_folds: int, test_size: float, experiment_name: str) -> None:
    MODELS_DIR.mkdir(exist_ok=True)
    FIG_DIR.mkdir(parents=True, exist_ok=True)

    # SQLite-backed tracking store (the plain filesystem store is in MLflow's
    # maintenance mode as of 2.x+); artifacts (plots, models) still land as
    # files under ./mlruns alongside the mlflow.db metadata database.
    mlflow.set_tracking_uri("sqlite:///mlflow.db")
    mlflow.set_experiment(experiment_name)

    df = load_and_clean(data_path)
    X, y = split_features_target(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=RANDOM_STATE, stratify=y,
    )
    print(f"Train size: {len(X_train)}, Test size: {len(X_test)}")

    results = []
    for name, spec in MODEL_GRID.items():
        result = run_model(name, spec, X_train, X_test, y_train, y_test, cv_folds)
        results.append(result)

    best = max(results, key=lambda r: r["test_metrics"]["roc_auc"])
    print(f"\n=== Best model: {best['name']} (test ROC-AUC={best['test_metrics']['roc_auc']:.4f}) ===")

    model_path = MODELS_DIR / "model.pkl"
    joblib.dump(best["pipeline"], model_path)

    metadata = {
        "model_name": best["name"],
        "mlflow_run_id": best["run_id"],
        "best_params": best["best_params"],
        "cv_best_roc_auc": best["cv_best_roc_auc"],
        "test_metrics": best["test_metrics"],
        "feature_columns": list(X.columns),
    }
    (MODELS_DIR / "metadata.json").write_text(json.dumps(metadata, indent=2))

    comparison = pd.DataFrame(
        [{"model": r["name"], "cv_roc_auc": r["cv_best_roc_auc"], **r["test_metrics"]} for r in results]
    )
    comparison.to_csv("reports/model_comparison.csv", index=False)
    print(f"\nSaved best model -> {model_path}")
    print(f"Saved metadata   -> {MODELS_DIR / 'metadata.json'}")
    print("Saved comparison -> reports/model_comparison.csv")
    print("\n", comparison.to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data/processed/heart_disease_clean.csv")
    parser.add_argument("--cv", type=int, default=5, help="number of cross-validation folds")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--experiment-name", default="heart-disease-classification")
    args = parser.parse_args()
    main(args.data, args.cv, args.test_size, args.experiment_name)
