"""
Standalone CLI inference script - loads the packaged model (models/model.pkl)
and scores one patient, without needing the API running. Useful for quickly
proving the saved pipeline is reproducible and self-contained.

Usage:
    python src/predict.py --json '{"age":63,"sex":1,"cp":3,"trestbps":145,
        "chol":233,"fbs":1,"restecg":0,"thalach":150,"exang":0,"oldpeak":2.3,
        "slope":0,"ca":0,"thal":1}'

    # or from a file containing one JSON object:
    python src/predict.py --file sample_patient.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

from data_preprocessing import FEATURE_COLUMNS

MODEL_PATH = Path("models/model.pkl")
METADATA_PATH = Path("models/metadata.json")


def predict(record: dict) -> dict:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"{MODEL_PATH} not found - run `python src/train.py` first.")

    model = joblib.load(MODEL_PATH)
    metadata = json.loads(METADATA_PATH.read_text()) if METADATA_PATH.exists() else {}

    missing = set(FEATURE_COLUMNS) - set(record)
    if missing:
        raise ValueError(f"Missing required feature(s): {sorted(missing)}")

    row = pd.DataFrame([record])[FEATURE_COLUMNS]
    proba_disease = float(model.predict_proba(row)[0, 1])
    prediction = int(proba_disease >= 0.5)
    confidence = proba_disease if prediction == 1 else 1 - proba_disease

    return {
        "prediction": prediction,
        "label": "disease" if prediction == 1 else "no_disease",
        "confidence": round(confidence, 4),
        "probability_disease": round(proba_disease, 4),
        "model_name": metadata.get("model_name", "unknown"),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--json", help="Inline JSON object with the 13 feature values")
    group.add_argument("--file", help="Path to a JSON file with the 13 feature values")
    args = parser.parse_args()

    payload = json.loads(args.json) if args.json else json.loads(Path(args.file).read_text())
    result = predict(payload)
    print(json.dumps(result, indent=2))
