"""
Data loading, cleaning and feature-engineering pipeline for the Heart Disease
UCI dataset.

This module is the single source of truth for preprocessing: it is imported
by the EDA notebook, the training script, the unit tests AND the serving API,
so that training-time and inference-time transformations never drift apart
(the classic "training/serving skew" MLOps failure mode).

Dataset columns (14 total, see assignment brief / UCI repo id=45):
    age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak,
    slope, ca, thal, target
"""

from __future__ import annotations

from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RAW_COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal", "target",
]

# Continuous numeric features -> impute (median) + scale
NUMERIC_FEATURES = ["age", "trestbps", "chol", "thalach", "oldpeak"]

# Already-binary 0/1 features -> impute (most frequent) only, no scaling needed
BINARY_FEATURES = ["sex", "fbs", "exang"]

# Multi-category / discrete-coded features -> impute (most frequent) + one-hot encode
CATEGORICAL_FEATURES = ["cp", "restecg", "slope", "ca", "thal"]

TARGET_COLUMN = "target"

FEATURE_COLUMNS = NUMERIC_FEATURES + BINARY_FEATURES + CATEGORICAL_FEATURES


def load_raw_data(path: str | Path) -> pd.DataFrame:
    """Load the raw CSV exactly as downloaded (no cleaning applied yet)."""
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    missing_cols = set(RAW_COLUMNS) - set(df.columns)
    if missing_cols:
        raise ValueError(f"Input data is missing expected columns: {missing_cols}")
    return df[RAW_COLUMNS].copy()


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean the raw dataframe.

    Handles the quirks of the original UCI 'processed.cleveland.data' table:
      * missing values are sometimes encoded as the literal string '?'
      * all columns may be read in as object/string dtype as a result
      * the target column is a 0-4 severity scale in the *original* UCI file;
        per the assignment's binary classification problem statement we
        collapse it to a binary presence/absence label (0 = no disease,
        1 = disease present, i.e. original value >= 1).
      * exact duplicate rows are dropped.

    NaNs introduced here are left in place; imputation happens inside the
    sklearn Pipeline (build_preprocessing_pipeline) so that the same fitted
    imputer is reused at inference time.
    """
    df = df.copy()

    # 1) Normalise missing-value markers used by the original UCI dump
    df = df.replace("?", np.nan)

    # 2) Coerce every column to numeric (raises if something is unexpectedly non-numeric)
    for col in RAW_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # 3) Drop exact duplicate rows
    before = len(df)
    df = df.drop_duplicates()
    dropped = before - len(df)
    if dropped:
        print(f"[clean_data] dropped {dropped} exact duplicate row(s)")

    # 4) Collapse target to binary presence/absence of heart disease
    df[TARGET_COLUMN] = (df[TARGET_COLUMN] > 0).astype(int)

    df = df.reset_index(drop=True)
    return df


def split_features_target(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    X = df[FEATURE_COLUMNS].copy()
    y = df[TARGET_COLUMN].copy()
    return X, y


def build_preprocessing_pipeline() -> ColumnTransformer:
    """Build the sklearn ColumnTransformer used for both training and inference.

    - numeric continuous features : median impute -> standard scale
    - binary features             : most-frequent impute -> passthrough
    - categorical features        : most-frequent impute -> one-hot encode
    """
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    binary_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, NUMERIC_FEATURES),
            ("bin", binary_transformer, BINARY_FEATURES),
            ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ]
    )
    return preprocessor


def load_and_clean(path: str | Path) -> pd.DataFrame:
    """Convenience wrapper: load raw CSV and apply cleaning in one call."""
    return clean_data(load_raw_data(path))


if __name__ == "__main__":
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "data/raw/heart_disease_uci.csv"
    data = load_and_clean(path)
    print(data.describe(include="all"))
    print("\nClass balance:\n", data[TARGET_COLUMN].value_counts(normalize=True))
