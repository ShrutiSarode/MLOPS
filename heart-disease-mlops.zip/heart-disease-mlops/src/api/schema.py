"""Pydantic request/response schemas for the heart-disease prediction API."""

from pydantic import BaseModel, Field


class PatientFeatures(BaseModel):
    """One patient's raw feature values, exactly as collected clinically.

    Field descriptions follow the standard UCI Heart Disease attribute codes.
    """

    age: float = Field(..., ge=0, le=120, description="Age in years", examples=[63])
    sex: int = Field(..., ge=0, le=1, description="1 = male, 0 = female", examples=[1])
    cp: int = Field(..., ge=0, le=3, description="Chest pain type (0-3)", examples=[3])
    trestbps: float = Field(..., ge=0, description="Resting blood pressure (mm Hg)", examples=[145])
    chol: float = Field(..., ge=0, description="Serum cholesterol (mg/dl)", examples=[233])
    fbs: int = Field(
        ..., ge=0, le=1, description="Fasting blood sugar > 120 mg/dl (1=true, 0=false)", examples=[1]
    )
    restecg: int = Field(..., ge=0, le=2, description="Resting ECG results (0-2)", examples=[0])
    thalach: float = Field(..., ge=0, description="Max heart rate achieved", examples=[150])
    exang: int = Field(..., ge=0, le=1, description="Exercise-induced angina (1=yes, 0=no)", examples=[0])
    oldpeak: float = Field(
        ..., description="ST depression induced by exercise relative to rest", examples=[2.3]
    )
    slope: int = Field(
        ..., ge=0, le=2, description="Slope of the peak exercise ST segment (0-2)", examples=[0]
    )
    ca: int = Field(
        ..., ge=0, le=4, description="Number of major vessels (0-4) colored by fluoroscopy", examples=[0]
    )
    thal: int = Field(..., ge=0, le=3, description="Thalassemia (0-3)", examples=[1])

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "age": 63, "sex": 1, "cp": 3, "trestbps": 145, "chol": 233,
                    "fbs": 1, "restecg": 0, "thalach": 150, "exang": 0,
                    "oldpeak": 2.3, "slope": 0, "ca": 0, "thal": 1,
                }
            ]
        }
    }


class PredictionResponse(BaseModel):
    prediction: int = Field(..., description="0 = no disease, 1 = disease present")
    label: str = Field(..., description="Human-readable label")
    confidence: float = Field(
        ..., description="Model's predicted probability of the predicted class"
    )
    probability_disease: float = Field(
        ..., description="Raw predicted probability of class 1 (disease)"
    )
    model_name: str
    model_version: str


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_name: str | None = None
    model_version: str | None = None
