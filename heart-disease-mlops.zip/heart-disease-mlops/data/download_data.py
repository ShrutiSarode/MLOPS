"""
Download the Heart Disease UCI dataset.

Primary source : UCI Machine Learning Repository
                  https://archive.ics.uci.edu/dataset/45/heart+disease
Mirror used    : A verbatim GitHub mirror of the same 303-row / 14-attribute
                  "processed.cleveland.data" table (kb22/Heart-Disease-Prediction),
                  used because archive.ics.uci.edu does not always allow direct
                  script downloads (SSL/redirect quirks) from CI runners.

Usage:
    python data/download_data.py
    python data/download_data.py --out data/raw/heart_disease_uci.csv

The script will:
 1. Try the UCI source first (via the `ucimlrepo` package, same data, official source).
 2. Fall back to the GitHub mirror if `ucimlrepo` / the UCI endpoint is unreachable
    (common on sandboxed/CI machines with restricted egress).
"""

import argparse
import sys
from pathlib import Path

import pandas as pd

UCI_MIRROR_URL = (
    "https://raw.githubusercontent.com/kb22/Heart-Disease-Prediction/"
    "master/dataset.csv"
)

COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal", "target",
]


def download_via_ucimlrepo() -> pd.DataFrame:
    """Fetch directly from the UCI ML Repository using the official package."""
    from ucimlrepo import fetch_ucirepo  # imported lazily: optional dependency

    heart_disease = fetch_ucirepo(id=45)  # Heart Disease dataset, UCI id=45
    X = heart_disease.data.features
    y = heart_disease.data.targets
    df = pd.concat([X, y], axis=1)
    df.columns = COLUMNS
    return df


def download_via_mirror() -> pd.DataFrame:
    """Fetch the same table from a GitHub mirror (reachable from most networks)."""
    df = pd.read_csv(UCI_MIRROR_URL)
    df.columns = [c.strip().lower() for c in df.columns]
    return df[COLUMNS]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out",
        default="data/raw/heart_disease_uci.csv",
        help="Output path for the raw CSV (default: data/raw/heart_disease_uci.csv)",
    )
    args = parser.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    df = None
    try:
        print("Attempting download from UCI ML Repository (ucimlrepo)...")
        df = download_via_ucimlrepo()
        print(f"  -> success, {len(df)} rows from UCI directly.")
    except Exception as exc:  # noqa: BLE001 - we want any failure to fall through
        print(f"  -> UCI direct fetch failed ({exc!r}); falling back to mirror.")
        try:
            df = download_via_mirror()
            print(f"  -> success, {len(df)} rows from mirror.")
        except Exception as exc2:  # noqa: BLE001
            print(f"  -> mirror fetch also failed ({exc2!r}).", file=sys.stderr)
            sys.exit(1)

    df.to_csv(out_path, index=False)
    print(f"Saved raw dataset to {out_path.resolve()} ({len(df)} rows, {len(df.columns)} cols)")


if __name__ == "__main__":
    main()
